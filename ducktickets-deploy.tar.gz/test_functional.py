#!/usr/bin/env python3
"""
Teste funcional completo do DuckTickets
Testa todas as funcionalidades principais do sistema
"""

import requests
import json
import time
from datetime import datetime, timedelta

BASE_URL = "http://localhost:8000"

def test_health():
    """Testa endpoint de saúde"""
    print("🔍 Testando Health Check...")
    response = requests.get(f"{BASE_URL}/healthz")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    print("✅ Health Check OK")

def test_pages():
    """Testa se todas as páginas carregam"""
    print("\n🔍 Testando Páginas...")
    
    pages = [
        ("/", "Homepage"),
        ("/login", "Login"),
        ("/admin-login", "Admin Login"),
        ("/meus-ingressos", "Meus Ingressos")
    ]
    
    for url, name in pages:
        response = requests.get(f"{BASE_URL}{url}")
        assert response.status_code == 200, f"{name} falhou"
        print(f"✅ {name} OK")

def test_admin_api():
    """Testa API administrativa"""
    print("\n🔍 Testando API Admin...")
    
    # Listar eventos
    response = requests.get(f"{BASE_URL}/admin/events")
    assert response.status_code == 200
    events = response.json()
    print(f"✅ {len(events)} eventos encontrados")
    
    if events:
        event_id = events[0]["id"]
        print(f"✅ Primeiro evento: {events[0]['name']}")
        
        # Listar lotes do evento
        response = requests.get(f"{BASE_URL}/admin/batches/{event_id}")
        if response.status_code == 200:
            batches = response.json()
            print(f"✅ {len(batches)} lotes encontrados")
        else:
            print(f"⚠️ Nenhum lote encontrado para evento {event_id}")

def test_checkout_flow():
    """Testa fluxo de checkout"""
    print("\n🔍 Testando Fluxo de Checkout...")
    
    # Pegar eventos disponíveis
    response = requests.get(f"{BASE_URL}/admin/events")
    events = response.json()
    
    if not events:
        print("⚠️ Nenhum evento para testar checkout")
        return
    
    event_id = events[0]["id"]
    
    # Testar página de checkout
    response = requests.get(f"{BASE_URL}/checkout", params={"event_id": event_id})
    # Pode retornar 307 (redirect) ou 200
    assert response.status_code in [200, 307]
    print("✅ Página de checkout acessível")

def test_database_content():
    """Verifica conteúdo do banco"""
    print("\n🔍 Testando Conteúdo do Banco...")
    
    # Eventos
    response = requests.get(f"{BASE_URL}/admin/events")
    events = response.json()
    print(f"✅ Eventos no banco: {len(events)}")
    
    for event in events:
        print(f"   📅 {event['name']} - {event['location']}")
        
        # Lotes de cada evento
        response = requests.get(f"{BASE_URL}/admin/batches/{event['id']}")
        if response.status_code == 200:
            batches = response.json()
            print(f"      🎫 {len(batches)} lotes de ingressos")
        else:
            print(f"      🎫 0 lotes de ingressos")

def test_api_endpoints():
    """Testa endpoints da API"""
    print("\n🔍 Testando Endpoints da API...")
    
    endpoints = [
        ("GET", "/healthz", "Health Check"),
        ("GET", "/admin/events", "Listar Eventos"),
        ("GET", "/admin/status", "Status Admin"),
    ]
    
    for method, endpoint, name in endpoints:
        if method == "GET":
            response = requests.get(f"{BASE_URL}{endpoint}")
        
        print(f"   {method} {endpoint} - Status: {response.status_code}")
        assert response.status_code in [200, 404, 307], f"{name} falhou"
    
    print("✅ Endpoints básicos funcionando")

def test_frontend_elements():
    """Testa elementos do frontend"""
    print("\n🔍 Testando Elementos do Frontend...")
    
    # Homepage
    response = requests.get(f"{BASE_URL}/")
    html = response.text
    
    # Verificar elementos essenciais
    checks = [
        ("DuckTickets", "Logo presente"),
        ("Eventos Disponíveis", "Título da seção"),
        ("carousel", "Carrossel presente"),
        ("Orbitron", "Fonte do logo"),
    ]
    
    for element, description in checks:
        if element in html:
            print(f"✅ {description}")
        else:
            print(f"⚠️ {description} - não encontrado")

def test_frontend_links():
    """Testa todos os links do frontend"""
    print("\n🔍 Testando Links do Frontend...")
    
    import re
    from urllib.parse import urljoin, urlparse
    
    pages_to_test = [
        ("/", "Homepage"),
        ("/login", "Login"),
        ("/admin-login", "Admin Login"),
        ("/meus-ingressos", "Meus Ingressos"),
        ("/admin", "Admin Panel")
    ]
    
    all_links = set()
    
    for page_url, page_name in pages_to_test:
        try:
            response = requests.get(f"{BASE_URL}{page_url}", allow_redirects=True)
            if response.status_code != 200:
                print(f"⚠️ {page_name} não acessível (Status: {response.status_code})")
                continue
                
            html = response.text
            
            # Encontrar todos os links href
            href_links = re.findall(r'href=["\']([^"\'>]+)["\']', html)
            
            # Encontrar todos os links de ação (onclick com window.location)
            onclick_links = re.findall(r'window\.location\.href\s*=\s*["\']([^"\'>]+)["\']', html)
            
            # Encontrar formulários action
            form_actions = re.findall(r'action=["\']([^"\'>]+)["\']', html)
            
            page_links = href_links + onclick_links + form_actions
            
            print(f"\n📄 {page_name}:")
            
            for link in page_links:
                if link.startswith('#') or link.startswith('javascript:') or link.startswith('mailto:'):
                    continue
                    
                # Converter links relativos para absolutos
                if link.startswith('/'):
                    full_link = f"{BASE_URL}{link}"
                elif link.startswith('http'):
                    full_link = link
                else:
                    full_link = f"{BASE_URL}/{link}"
                
                all_links.add((full_link, link, page_name))
                
                # Testar o link
                try:
                    link_response = requests.get(full_link, allow_redirects=True, timeout=5)
                    status = link_response.status_code
                    
                    if status == 200:
                        print(f"   ✅ {link} - OK")
                    elif status in [301, 302, 307, 308]:
                        print(f"   🔄 {link} - Redirect ({status})")
                    elif status == 404:
                        print(f"   ❌ {link} - Not Found")
                    else:
                        print(f"   ⚠️ {link} - Status {status}")
                        
                except requests.exceptions.RequestException as e:
                    print(f"   ❌ {link} - Erro: {str(e)[:50]}...")
                    
        except Exception as e:
            print(f"❌ Erro ao testar {page_name}: {str(e)[:50]}...")
    
    print(f"\n📊 Total de links únicos testados: {len(all_links)}")
    
    # Testar links específicos importantes
    important_links = [
        "/", "/login", "/admin-login", "/meus-ingressos", "/admin",
        "/healthz", "/admin/events", "/admin/status"
    ]
    
    print("\n🎯 Testando Links Importantes:")
    for link in important_links:
        try:
            response = requests.get(f"{BASE_URL}{link}", allow_redirects=True, timeout=5)
            status = response.status_code
            
            if status == 200:
                print(f"   ✅ {link} - OK")
            elif status in [301, 302, 307, 308]:
                print(f"   🔄 {link} - Redirect")
            else:
                print(f"   ⚠️ {link} - Status {status}")
                
        except Exception as e:
            print(f"   ❌ {link} - Erro")

def run_all_tests():
    """Executa todos os testes"""
    print("🚀 INICIANDO TESTES FUNCIONAIS DO DUCKTICKETS")
    print("=" * 50)
    
    try:
        test_health()
        test_pages()
        test_admin_api()
        test_checkout_flow()
        test_database_content()
        test_api_endpoints()
        test_frontend_elements()
        test_frontend_links()
        
        print("\n" + "=" * 50)
        print("🎉 TODOS OS TESTES FUNCIONAIS PASSARAM!")
        print("✅ Sistema funcionando corretamente")
        
    except Exception as e:
        print(f"\n❌ ERRO NO TESTE: {e}")
        print("🔧 Verifique se o servidor está rodando: uvicorn app.main:app --reload")
        return False
    
    return True

if __name__ == "__main__":
    success = run_all_tests()
    exit(0 if success else 1)