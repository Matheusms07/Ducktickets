#!/usr/bin/env python3
"""
Script para executar TODOS os testes do DuckTickets
- Testes unitários (pytest)
- Testes funcionais completos
- Testes de links do frontend
"""

import subprocess
import sys
import time
import requests
import os

def run_unit_tests():
    """Executa testes unitários com pytest"""
    print("🧪 EXECUTANDO TESTES UNITÁRIOS")
    print("=" * 50)
    
    result = subprocess.run([
        sys.executable, "-m", "pytest", "tests/", "-v"
    ], capture_output=True, text=True)
    
    print(result.stdout)
    if result.stderr:
        print("STDERR:", result.stderr)
    
    return result.returncode == 0

def start_server():
    """Inicia servidor para testes funcionais"""
    print("\n🚀 INICIANDO SERVIDOR PARA TESTES...")
    
    # Matar processos existentes
    subprocess.run(["pkill", "-f", "uvicorn"], capture_output=True)
    time.sleep(2)
    
    # Iniciar servidor
    process = subprocess.Popen([
        sys.executable, "-m", "uvicorn", "app.main:app", 
        "--host", "0.0.0.0", "--port", "8000"
    ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    # Aguardar servidor iniciar
    for i in range(10):
        try:
            response = requests.get("http://localhost:8000/healthz", timeout=2)
            if response.status_code == 200:
                print("✅ Servidor iniciado com sucesso!")
                return process
        except:
            time.sleep(1)
    
    print("❌ Falha ao iniciar servidor")
    return None

def run_functional_tests():
    """Executa testes funcionais"""
    print("\n🔍 EXECUTANDO TESTES FUNCIONAIS")
    print("=" * 50)
    
    result = subprocess.run([
        sys.executable, "test_functional.py"
    ], capture_output=True, text=True)
    
    print(result.stdout)
    if result.stderr:
        print("STDERR:", result.stderr)
    
    return result.returncode == 0

def stop_server(process):
    """Para o servidor"""
    if process:
        process.terminate()
        process.wait()
    subprocess.run(["pkill", "-f", "uvicorn"], capture_output=True)

def main():
    """Executa todos os testes"""
    print("🦆 DUCKTICKETS - SUITE COMPLETA DE TESTES")
    print("=" * 60)
    
    results = []
    
    # 1. Testes unitários
    unit_success = run_unit_tests()
    results.append(("Testes Unitários", unit_success))
    
    # 2. Testes funcionais (precisa do servidor)
    server_process = start_server()
    if server_process:
        functional_success = run_functional_tests()
        results.append(("Testes Funcionais", functional_success))
        stop_server(server_process)
    else:
        results.append(("Testes Funcionais", False))
    
    # Resumo final
    print("\n" + "=" * 60)
    print("📊 RESUMO DOS TESTES")
    print("=" * 60)
    
    all_passed = True
    for test_name, success in results:
        status = "✅ PASSOU" if success else "❌ FALHOU"
        print(f"{test_name:.<30} {status}")
        if not success:
            all_passed = False
    
    print("=" * 60)
    if all_passed:
        print("🎉 TODOS OS TESTES PASSARAM!")
        print("✅ Sistema funcionando perfeitamente")
    else:
        print("⚠️ ALGUNS TESTES FALHARAM")
        print("🔧 Verifique os logs acima")
    
    return 0 if all_passed else 1

if __name__ == "__main__":
    exit(main())